// This file was @generated automatically

#define SAMPLE_OUTPUT { \
  0x50402000, 0xffffffff, 0x00000004, 0x00000168, 0xffffa61f, 0xffff343c, 0x00014af4, 0x00000000 \
}
